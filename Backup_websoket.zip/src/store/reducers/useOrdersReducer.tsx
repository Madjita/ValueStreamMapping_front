import { createSlice, PayloadAction,current } from '@reduxjs/toolkit'
import IDataOrder from '../../Component/Data/IDataOrder'
import { useOrdersType } from '../../type/useOrdersType'


/*let initialState: useOrdersType ={
    orders: [],
    loading: true,
    changeList: false,
    error: null
}*/

const useOrdersReducer = createSlice({  
    name: 'orders',  
    initialState: {
        orders: new Array as IDataOrder[],
        loading: true,
        changeList: false,
        error: null
    } as useOrdersType,  
    reducers: {       
        fetch_orders(state) {  
            //state.loading = true     
        },
        fetch_orders_success: (state,action) => {   

            var currentState = current(state);

            if(currentState.orders.length === 0 || currentState.orders.length < action.payload.length)
            {
                console.log("sdf =",current(state))

                return {...state, orders: action.payload, loading: false }
            }


           /* action.payload.map((item:IDataOrder,index: number )=>{
                if(item.tActual != 0 || currentState.orders[index].orderRole != item.orderRole )
                {
                    console.log("fetch_orders_update = " +item.tActual,currentState.orders[index].orderRole != item.orderRole );
                    console.log("fetch_orders_update = " +currentState.orders[index].orderRole, item.orderRole );
                    //fetch_orders_update(item)
                }
            })*/

            state.orders = action.payload 
            state.loading = false     

        },     
        fetch_orders_error(state, action) {     
            state.loading = false    
            state.error = action.payload    
        },
        fetch_orders_add(state, action){
            console.log("fetch_orders_add =",state,action)
            //state.orders.push(action.payload);
        },
        fetch_orders_update(state, action){
            var currentState = current(state);

           let newData  = currentState.orders.map(o => {
                if (o.id === action.payload.id) {
                  return action.payload;
                }
            }) as IDataOrder[]


            return {...state, orders: newData}
        }   
    },
    /*extraReducers:{

    }*/
})
export default useOrdersReducer.reducer
export const { fetch_orders, fetch_orders_success, fetch_orders_error,fetch_orders_add,fetch_orders_update } = useOrdersReducer.actions