import React,{useState} from 'react'
import Card from '@material-ui/core/Card'
import CardHeader from '@material-ui/core/CardHeader'
import IconButton from '@material-ui/core/IconButton'
import MoreVertIcon from '@material-ui/icons/MoreVert';
import IDataBufferVSM from '../Data/IDataBufferVSM';
import CardContent from '@material-ui/core/CardContent'
import Typography from '@material-ui/core/Typography'
import List from '@material-ui/core/List'
import ListItem from '@material-ui/core/ListItem'
import ListItemText from '@material-ui/core/ListItemText'
import Divider from '@material-ui/core/Divider'

import IDataEtapVSM from '../Data/IDataEtapVSM'
import IUser from '../Data/IUser';
import IDataOrderItem from '../Data/IDataOrderItem';
import IDataOrder from '../Data/IDataOrderPart';
import SettingsIcon from '@material-ui/icons/Settings';

interface IDataResourceOrder
{
  
    user: IUser;
    orderItem: IDataOrderItem,
}

const Etap =  (props:{etap: IDataEtapVSM}) => {

    const Colors = { RED: 'red', GREEN: 'green', YELLOW: 'yellow', WHITE: 'white', Header: '#6495ed'};

    const 
    {
        name
    } = props.etap

    const [information, setInformation] = useState({
        resources: new Array as IDataResourceOrder[],
        etap: new Object as IDataBufferVSM,
        show: true
      });

      

    let Example = {
        resources: [
          {
            user: {
                name: "Иван Иванович"
            } as IUser,
            orderItem: {
                id: 2,
                tActual: 1,
            } as IDataOrderItem
            
  
          } as IDataResourceOrder,
        ],
        etap : null,
        show: false
      }
  
     if(information.resources.length <= 0 )
     {
      setInformation(Example as any);
     }


    const listResource = information.resources.map((item: IDataResourceOrder, i: number)=>{

        let time2 = "21"
        let time = "23"
        return  (
            <div key={i} style={{padding: '0px', margin: '0px'}}>
            <div  style={{fontWeight: 'bold',fontSize:'1rem', backgroundColor: "#7366bd", padding: '10px', color: 'white'}} >{item.user?.name}</div>
                    <div>
                    {
                      item ? 
                        <div style={{padding: 0, margin: 0,borderRight: '1px solid rgba(0, 0, 21, 0.125)', backgroundColor: Colors.YELLOW}}>
                         {/* <p style={{display: 'flex', justifyContent:'center', fontWeight: 'bold'}} >Партия {item?.order.id}</p> */}
                          <div style={{display: 'flex', justifyContent:'space-around'}} >
                            <p>№ Текущего заказа</p>
                            <p>Всего заказов</p>
                          </div>
                         {/*  <div style={{display: 'flex', justifyContent:'space-around'}} >
                            <p >{item?.part}</p>
                            <p >{item?.order.quantity}</p>
                          </div>*/}
                          <p style={{display: 'flex', justifyContent:'center'}} >Время выполнения</p>
                          <p style={{display: 'flex', justifyContent:'center', fontWeight: 'bold'}}>{time2}</p>
  
                          <p style={{display: 'flex', justifyContent:'center'}} >Общее время заказа</p>
                          <p style={{display: 'flex', justifyContent:'center', fontWeight: 'bold'}}>{time}</p>
                        </div>
                      :   <div style={{padding: 0, margin: 0,borderRight: '1px solid rgba(0, 0, 21, 0.125)', backgroundColor: Colors.GREEN}}>
                          <p style={{display: 'flex', justifyContent:'center'}} >Свободен</p>
                      </div>
                    }
                    </div>
  
              </div>
        )
    })
    
    return(
        <Card sx={{ maxWidth: 200,verticalAlign: 'middle' }}>
            <CardHeader
            action={
                <IconButton aria-label="settings">
                  <SettingsIcon />
                </IconButton>
              }
            title={name}
            sx={{fontWeight: 'bold', backgroundColor: Colors.Header,color: 'white',paddingBottom: '0px'}}>

            </CardHeader>
            <div  style={{fontWeight: 'bold',fontSize:'1rem',backgroundColor: Colors.Header,color: 'white', display: 'flex', justifyContent: 'space-around'}}>
              <p>Время цикла:</p>
              <p>55</p>
            </div>
            <CardContent sx={{padding: '0px', margin: '0px'}}>
                {listResource}
            </CardContent>
        </Card>
    )

}


export default Etap;