import React,{useState} from 'react'

import IDataCardSection from '../Data/IDataCardSection'
import IDataOrderItem from '../Data/IDataOrderItem'
import Divider from '@material-ui/core/Divider';
import IDataCardVSM from '../Data/IDataCardVSM';
import Paper from '@material-ui/core/Paper'
import ViewItemSection from './ViewItemSection'
import IDataOrder from '../Data/IDataOrder';



const ViewOrderCard =  (props: {sections : IDataCardSection[], orderItems?:IDataOrderItem[]}) => {
    //const [BDitems, setBDItem] = useState<IDataOrderItem[]>();
  
   // console.log("sections: ",props.sections)

    let flagParalel = false;
    let flagMaxInSectionItems = 0 as number;
    
    props.sections.map((item : IDataCardSection,index: number) =>
      {
         if(item.sections.length > flagMaxInSectionItems )
         {
            flagMaxInSectionItems = item.sections.length 
         }

         if(item.sections.length > 1)
         {
            flagParalel = true;
         }
      }
    )
    
    let card = props.sections.map((item : IDataCardSection,index: number) =>
         <ViewItemSection key={index} orderItems={props.orderItems} data={item.sections} numberSection={index} lastSection={props.sections.length} flagParalel={flagParalel} flagMaxInSectionItems={flagMaxInSectionItems}/>
    )


    return(
       <div style={{display: 'grid', justifyContent: 'center', gridTemplateColumns: 'repeat('+props.sections.length+',1fr)'}}>
          {card}
       </div>
    )

}


export default ViewOrderCard;