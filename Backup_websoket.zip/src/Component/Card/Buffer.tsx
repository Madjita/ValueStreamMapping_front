import React,{useEffect, useState} from 'react'
import { styled } from '@material-ui/core/styles';

import Triangle from './Triangle'

import Card from '@material-ui/core/Card'
import CardHeader from '@material-ui/core/CardHeader'
import CardContent from '@material-ui/core/CardContent'
import IconButton from '@material-ui/core/IconButton'
import MoreVertIcon from '@material-ui/icons/MoreVert';
import IDataBufferVSM from '../Data/IDataBufferVSM';

import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import {IconButtonProps} from '@material-ui/core/IconButton'

import Typography from '@material-ui/core/Typography';
import CardActions from '@material-ui/core/CardActions';
import Collapse from '@material-ui/core/Collapse';
import IDataOrderItem from '../Data/IDataOrderItem'
import SettingsIcon from '@material-ui/icons/Settings';
import axios from 'axios'

import ip from '../../global'
import IDatabufferVSMQueue from '../Data/IDatabufferVSMQueue';
import IDataOrder from '../Data/IDataOrder';
import OrderRole from '../Data/OrderRole';
import moment from 'moment'

interface ExpandMoreProps extends IconButtonProps {
    expand: boolean;
}

  

const Buffer = (props:{buffer: IDataBufferVSM, orderItems: IDataOrderItem[]}) => {

    const Colors = { RED: 'red', GREEN: 'green', YELLOW: 'yellow', WHITE: 'white', Header: '#6495ed'};

     const {
      name,
      max,
      minHold,
      valueDefault,
      type,
      value
    } = props.buffer;

    const ExpandMore = styled((props: ExpandMoreProps) => {
        const { expand, ...other } = props;
        return <IconButton {...other} />;
      })(({ theme, expand }) => ({
        transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
        marginLeft: 'auto',
        transition: theme.transitions.create('transform', {
          duration: theme.transitions.duration.shortest,
        }),
      }));

    const [expanded, setExpanded] = React.useState(true);
    const handleExpandClick = () => {
        setExpanded(!expanded);
    };

    const [information, setInformation] = useState({
      buffer: new Object as IDataBufferVSM,
      show: true
    });

    const [color,setColor] = useState('#d3d3d3');



   const fetchInfo  = async() =>{
    const response = await axios.post('http://'+ip+':5001/api/manufacture/updateInfoBuf',props.buffer,
    {
        headers: {
          "Access-Control-Allow-Origin": "*",
          'Content-Type': 'application/json'
        }
    })

    if(response.status === 200)
    {
      let data = response.data as IDataBufferVSM;


      let ex  = data.bufferVSMQueue.map((item: IDatabufferVSMQueue)=>{
        var f = props.orderItems.filter(o=> o.id === item.currentOrderItems.id)[0] as IDataOrderItem
        
        
        if(f.id === item.currentOrderItems.id)
        {
          return item
        }
      })


      data.bufferVSMQueue = ex as IDatabufferVSMQueue[];

     //console.log("es =",ex,data.bufferVSMQueue)




      return data;
    }
    
   }
   ///

   useEffect(() => {
    let isActive = true;
    fetchInfo().then(data => {
      if (isActive) setInformation({...information, buffer: data as IDataBufferVSM});
    });
    return () => { isActive = false };
  }, [information])



   
   let orderItems;

   if(information.buffer?.bufferVSMQueue != undefined || information.buffer?.bufferVSMQueue != null)
   {
   ///


     orderItems =  information.buffer?.bufferVSMQueue.map((item: IDatabufferVSMQueue, index: number) =>{
        var time = moment.unix(item.currentOrderItems.tActual as number).utc().format('H:m:s')
       // var time = "00:00:00"
  
        //console.log("saad = ", item);

        if(item === undefined)
        {
          return;
        }
    


        //borderRight: '1px solid rgba(0, 0, 21, 0.125)'
        return(
          <div key={index} style={{backgroundColor: color}}>
                <p style={{display: 'flex', justifyContent:'center', fontWeight: 'bold'}} >Партия {item.currentOrderItems.orders_production.id}</p>
                <div style={{display: 'flex', justifyContent:'space-around'}} >
                  <p>№ Текущего заказа</p>
                  <p>Всего заказов</p>
                </div>
                <div style={{display: 'flex', justifyContent:'space-around'}} >
                  <p >{item.currentOrderItems.part}</p>
                  <p >{item.currentOrderItems.orders_production.quantity}</p>
                </div>
                <p style={{display: 'flex', justifyContent:'center'}} >Общее время</p>
                <p style={{display: 'flex', justifyContent:'center', fontWeight: 'bold'}}>{time} сек</p>
          </div>
        )
      })

    }
      

    return(
        <Card sx={{ minWidth: '150px',verticalAlign: 'middle'}}>
            <CardHeader
                action={
                    <IconButton aria-label="settings">
                    <SettingsIcon />
                    </IconButton>
                }
                title={name}
                sx={{fontWeight: 'bold', color:'white', backgroundColor: Colors.Header,paddingBottom: '0px'}}>
            </CardHeader>
            <div  style={{fontWeight: 'bold',fontSize:'1rem',backgroundColor: Colors.Header,color: 'white', display: 'flex', justifyContent: 'space-around'}}>
              <p>Время цикла:</p>
              <p>55</p>
            </div>
            <CardContent style={{padding: 1}}>
                    <p style={{display: 'flex', justifyContent:'center', margin: 0}}> {max}</p>
                    <Triangle buff={{name: name, minHold: minHold, max: max,value: value,valueDefault: valueDefault} as IDataBufferVSM}/>
            </CardContent>
            <CardActions disableSpacing sx={{padding: 0, margin: 0}}>
                <ExpandMore
                    expand={expanded}
                    onClick={handleExpandClick}
                    aria-expanded={expanded}
                    aria-label="show more"
                >
                  <ExpandMoreIcon />
                </ExpandMore>
            </CardActions>
            <Collapse sx={{margin: 0, padding: 0, display: 'grid'}} in={expanded} timeout="auto" collapsedSize={0} unmountOnExit>
              {orderItems}
            </Collapse>
        </Card>
    )

}


export default Buffer;