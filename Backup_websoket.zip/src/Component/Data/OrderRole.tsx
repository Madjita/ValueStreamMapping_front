enum OrderRole { 
    Actual = 1,
    Work,
    Archive,
    Stoped
 };

 export default OrderRole;