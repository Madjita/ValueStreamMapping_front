import IDataCardVSM from './IDataCardVSM'

interface IDataCardSection {
    sections: IDataCardVSM[];
}

export default IDataCardSection;