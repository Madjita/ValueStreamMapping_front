interface IUser {
    id?: number;
    name?: string;
    department?: string;
    email?: string;
    patronymic?: string;
    position?: string;
    surname?: string;

    exeption?: string;
}

export default IUser;