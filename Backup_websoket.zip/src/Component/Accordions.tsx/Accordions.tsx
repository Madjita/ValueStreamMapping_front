import  React from 'react'

const Accordions = () =>
{
    return (
        <div>
            <p>Accordions</p>
        </div>
    )   
}


export default Accordions;