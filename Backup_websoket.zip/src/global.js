const  ip = '192.168.1.167'//'192.168.0.2' //'192.168.213.65' //'192.168.1.167'//'192.168.0.4'
const  URL_orderList = 'ws://'+ip+':5001/orderlist';

export default ip;
export {URL_orderList};