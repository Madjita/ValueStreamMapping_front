const  ip = '192.168.0.2'//'192.168.1.167'//'192.168.0.4'


export default ip;