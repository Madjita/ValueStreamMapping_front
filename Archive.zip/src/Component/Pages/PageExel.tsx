import  React from 'react'
import DropZone from '../DropZone/DropZone';

const PageExel = () =>
{
    return (
        <div>
            <DropZone/>
        </div>
    )   
}


export default PageExel;