import  React from 'react'

const PageOrderInArchive = () =>
{
    console.log("dsfsd")
    return (
        <div>
            <p>PageOrderInArchive</p>
        </div>
    )   
}


export default PageOrderInArchive;