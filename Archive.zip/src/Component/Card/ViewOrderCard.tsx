import React,{useEffect, useState} from 'react'

import IDataCardSection from '../Data/IDataCardSection'
import IDataOrderItem from '../Data/IDataOrderItem'
import Divider from '@material-ui/core/Divider';
import ViewCard from './ViewCard'

import CircularProgress from '@mui/material/CircularProgress';
import { Box } from '@material-ui/system';


import Card from '@material-ui/core/Card'
import CardHeader from '@material-ui/core/CardHeader'
import CardContent from '@material-ui/core/CardContent'

import IconButton from '@material-ui/core/IconButton'
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SettingsIcon from '@material-ui/icons/Settings';

import IDataVSM from '../Data/IDataVSM'
import IDataProduction from '../Data/IDataProduction';
import IDataCardVSM from '../Data/IDataCardVSM';
import { useCardVSMActionType, useProductionCardVSM } from '../../type/useCardVSMType';

import { useActionCardVSM } from '../../hooks/useActionCardVSM';
import { useTypedSelector } from '../../hooks/leftMenuSelector';
import IDataOrder from '../Data/IDataOrder';

/*
interface productionCardVSM{
    name: string,
    productions: IDataCardVSM[]
}
interface IDataCardProduct{
    cardVSMs: productionCardVSM[]
}*/


const ViewOrderCard =  (props: {order: IDataOrder}) => {
    const [BDitems, setBDItem] = useState<IDataOrderItem[]>();

    const {cardVSMs, loading} = useTypedSelector(state => state.cardVSM);
    const {cardVSMLoading} = useActionCardVSM()

    const [card, setCard] = useState(cardVSMs);

useEffect(() => {
    const timer = setTimeout(() => cardVSMLoading(props.order), 1000); 
    return () => {
      clearTimeout(timer);
      //console.log("timer ", orders);
    };  
   // console.log("cardVSMLoading useEffect" + props.order.name);
    //console.log("cardVSMLoading " + props.order.name);
},[cardVSMs]) //orders

//console.log("rerender ViewOrderCard")
//return <p>;o</p>;

if(loading)
{
    return (
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
    )
}

    let listProduct = cardVSMs.map((item: useProductionCardVSM, index: number)=>{
        

        let orderItemsFind = props.order.orders_production.filter(o=> o.production.name == item.name)

        let orderItems = null;
        if(orderItemsFind.length > 0)
        {
            orderItems = orderItemsFind[0].orders_production_items;
        }
        console.log(orderItems)

        return(
            <Card key={index} sx={{marginBottom: '150px'}}>
                <CardHeader
                    action={
                        <IconButton aria-label="settings">
                            <SettingsIcon />
                        </IconButton>
                    }
                    title={item.name}
                    sx={{fontWeight: 'bold',color: 'white', backgroundColor: '#575757'}}
                >
                </CardHeader>
                <CardContent sx={{backgroundColor: 'rgba(0, 0, 0, .03)'}}>
                    <ViewCard sections={item.sections} orderItems={orderItems as IDataOrderItem[]}/> 
               </CardContent>
            </Card>

        )
    })

    return(
       <div>
           {listProduct}
       </div>
    )
    
}


export default ViewOrderCard;