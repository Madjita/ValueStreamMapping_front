import React from 'react'
import IDataCardVSM from '../Data/IDataCardVSM'
import IDataOrderItem from '../Data/IDataOrderItem'
import IDataBufferVSM from '../Data/IDataBufferVSM'
import IDataEtapVSM from '../Data/IDataEtapVSM'

import Buffer from './Buffer'
import Etap from './Etap'

import ArrowRightAltIcon from '@material-ui/icons/ArrowRightAlt';
import IDataOrder from '../Data/IDataOrder'

const ViewItemSection = (props:{data: IDataCardVSM[],order?: IDataOrder, orderItems?: IDataOrderItem[], numberSection: number, lastSection: number, flagParalel: boolean,flagMaxInSectionItems: number}) =>
{
  const listSections = props.data.map((item : IDataCardVSM, index: number,) =>{

    let flag = props.flagParalel && props.data.length <= props.flagMaxInSectionItems-1 && index == 0;

    let delta = props.data.length;


    let percentPadding = (props.flagMaxInSectionItems-delta)*50 as any;
    

    if(props.data.length === props.flagMaxInSectionItems)
    {
      percentPadding = 0;
    }


    return (
    <div key={index} style={{display: 'block ruby', paddingTop: flag ? (percentPadding+'%') as string: '', marginBottom: props.data.length < 2 ? '':'50px'}}>
      <Buffer buffer={item.bufferVSM as IDataBufferVSM} orderItems={props.orderItems as IDataOrderItem[]}/>
      <div style={{verticalAlign: 'middle'}}>
        <ArrowRightAltIcon style={{width: '50px', height: '100%'}}/>
      </div>
      <Etap etap={item.etapVSM as IDataEtapVSM}/>
      {props.numberSection !==  props.lastSection ? 
        <div style={{verticalAlign: 'middle'}}>
          <ArrowRightAltIcon style={{width: '50px', height: '100%'}}/>
        </div>
      :
       null}
    </div>)
  })

 
 

  return(
    <div style={{display: listSections.length < 1 ?'block ruby': '', border: '2px dashed #cec9c9', marginRight: '20px', padding: '50px'}}>
        {listSections}
    </div>
  )
}

export default ViewItemSection;