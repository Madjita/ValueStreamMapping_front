interface IDataResultVSM{
     id?: number;

     exeption?: string;
}

export default IDataResultVSM;