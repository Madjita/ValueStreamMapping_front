export enum IDataColorOrderInDefault{
    NotWork = 'gray', 
    InWork = 'orange', 
    Done = 'green', 
    Stoped = '#ff2400'
}