import IDialogAddOrderItem from './IDialogAddOrderItem'

export default interface IDialogAddOrder
{
    name: string,
    priority: number,
    products: IDialogAddOrderItem[]
}

