export default interface IDialogAddOrderItem 
{
    id: number
    name: string,
    quantity: number
}

