import IDataOrder from '../Component/Data/IDataOrder'

export enum useOrdersActionType{
    FETCH_ORDERS = 'FETCH_ORDERS',
    FETCH_ORDERS_SUCCESS = 'FETCH_ORDERS_SUCCESS',
    FETCH_ORDERS_ERROR = 'FETCH_ORDERS_ERROR'
}

export interface useOrdersType{
    orders: IDataOrder[],
    loading: boolean,
    changeList: boolean,
    error: null | string
}

interface FetchOrdersAction{
    type : useOrdersActionType.FETCH_ORDERS,
}

interface FetchOrdersActionSuccess{
    type : useOrdersActionType.FETCH_ORDERS_SUCCESS,
    payload: IDataOrder[],
}

interface FetchOrdersActionError{
    type : useOrdersActionType.FETCH_ORDERS_ERROR,
    payload: string,
}

export type useLeftMenuAction = FetchOrdersAction | FetchOrdersActionSuccess | FetchOrdersActionError